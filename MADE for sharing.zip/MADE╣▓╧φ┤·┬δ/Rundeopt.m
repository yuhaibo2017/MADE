%********************************************************************
% Script file for the initialization and run of the differential 
% evolution optimizer.
%********************************************************************
clear,clc,tic;
warning('off');
rng('default');
rng('shuffle');

%-------------- Basic benchmark problems --------------------
funcnum=1;
if funcnum==1 %---Ellipsoid 
    fname='Ellipsoid';
    Xmin=-5.12;Xmax=5.12;
    VRmin=-5.12;VRmax=5.12;
elseif funcnum==2 %---Rosenbrock
    fname='Rosenbrock';
    Xmin=-2.048;Xmax=2.048;
    VRmin=-2.048;VRmax=2.048;
elseif funcnum==3 %---Ackley 
    fname='Ackley';
    Xmin=-32.768;Xmax=32.768;
    VRmin=-32.768;VRmax=32.768;
elseif funcnum==4 %---Griewank
    fname='Griewank';
    Xmin=-600;Xmax=600;
    VRmin=-600;VRmax=600;
elseif funcnum==5 %---Rastrigins 
    fname='Rastrigin';
    Xmin=-5.12;Xmax=5.12;
    VRmin=-5.12;VRmax=5.12;
elseif funcnum==10 || funcnum==16 || funcnum==19 % CEC 2005 function F10/F16/F19
    fname='benchmark_func';
    Xmin=-5;Xmax=5;
    VRmin=-5;VRmax=5;    
end


%

%-------------- CEC 2014 Benchmark Problems --------------------
% fname = 'cec14_eotp_problems';
% funcnum=22;
% if funcnum==1 || funcnum==2 || funcnum==3 %---Shifted Sphere function 10d/20d/30d
%     Xmin=-20;Xmax=20;
%     VRmin=-20;VRmax=20;
%     if funcnum == 1;I_D = 10;elseif funcnum == 2;I_D = 20;elseif funcnum ==3;I_D = 30;end;
% elseif funcnum==4 || funcnum==5 || funcnum==6 %---Shifted Ellipsoid function  10d/20d/30d
%     Xmin=-20;Xmax=20;
%     VRmin=-20;VRmax=20;
%     if funcnum == 4;I_D = 10;elseif funcnum == 5;I_D = 20;elseif funcnum ==6;I_D = 30;end;
% elseif funcnum==7 || funcnum==8 || funcnum==9 %---Shifted and Rotated Ellipsoid function  10d/20d/30d
%     Xmin=-20;Xmax=20;
%     VRmin=-20;VRmax=20;
%     if funcnum == 7;I_D = 10;elseif funcnum == 8;I_D = 20;elseif funcnum ==9;I_D = 30;end;
% elseif funcnum==10 || funcnum==11 || funcnum==12 %---Shifted Step function  10d/20d/30d
%     Xmin=-20;Xmax=20;
%     VRmin=-20;VRmax=20;
%     if funcnum == 10;I_D = 10;elseif funcnum == 11;I_D = 20;elseif funcnum ==12;I_D = 30;end;
% elseif funcnum==13 || funcnum==14 || funcnum==15 %---Shifted Ackley��s function 10d/20d/30d
%     Xmin=-32;Xmax=32;
%     VRmin=-32;VRmax=32;
%     if funcnum == 13;I_D = 10;elseif funcnum == 14;I_D = 20;elseif funcnum ==15;I_D = 30;end;
% elseif funcnum==16 || funcnum==17 || funcnum==18 % Shifted Griewank��s function 10d/20d/30d
%     Xmin=-600;Xmax=600;
%     VRmin=-600;VRmax=600;    
%     if funcnum == 16;I_D = 10;elseif funcnum == 17;I_D = 20;elseif funcnum ==18;I_D = 30;end;
% elseif funcnum==19 || funcnum==20 || funcnum==21   % Shifted Rotated Rosenbrock��s function  10d/20d/30d
%     Xmin=-20;Xmax=20;
%     VRmin=-20;VRmax=20;    
%     if funcnum == 19;I_D = 10;elseif funcnum == 20;I_D = 20;elseif funcnum ==21;I_D = 30;end;
% elseif funcnum==22 || funcnum==23 || funcnum==24  % Shifted Rotated Rastrigin��s function  10d/20d/30d   
%     Xmin=-20;Xmax=20;
%     VRmin=-20;VRmax=20;
%     if funcnum == 22;I_D = 10;elseif funcnum == 23;I_D = 20;elseif funcnum ==24;I_D = 30;end;
% end
% S_struct.funcnum = funcnum;
%---------------------------------------------------------


% F_VTR		"Value To Reach" (stop when ofunc < F_VTR)
        F_VTR = 1.e-8; 

% I_D		number of parameters of the objective function 
        I_D = 20;% Common benchmark test suit
          
%         I_D = 30;% Energy minimization of a model molecular configuration: N=12.
%         I_D = 54; % 36D & 54D Novel Passive Vibration Isolator Feasibility
%         I_D = 31; % MOON ET AL. (2012) FUNCTION
% FVr_minbound,FVr_maxbound   vector of lower and upper bounds of initial population
%         the algorithm seems to work especially well if [FVr_minbound,FVr_maxbound] 
%         covers the region where the global minimum is expected
%         *** note: these are no bound constraints!! ***
        FVr_minbound = Xmin.*ones(1,I_D); % Common Benchmark Function
        FVr_maxbound = Xmax.*ones(1,I_D); % Common Benchmark Function
        
        
        I_bnd_constr = 1;  %1: use bounds as bound constraints, 0: no bound constraints      
        
% eta: the minimum distance threshold between samples to avoid samples getting too close to each other. 
        eta = min(sqrt(0.001^2*I_D), 5.0*1e-5*I_D*min(FVr_maxbound-FVr_minbound)); 
        
% I_NP            number of population members
    if I_D <= 30
        I_NP = 5*I_D; % for 10d & 20d & 30d
    elseif I_D == 50
        I_NP = 150; % for 30d & 50d & 100d
    end

%     I_NP = 30;
    
% I_itermax       maximum number of iterations (generations)
    I_itermax = 100; 
        
% I_evalmax       maximum number of fitness evaluation 
    if I_D <= 30
        I_evalmax = 11*I_D;    % for comparison with CAL-SAPSO.Dr.Handing Wang   
    else
        I_evalmax = 1000;        % for common benchmark test suit      
    end

    
    sn1=1;  gfs=zeros(1,fix(I_evalmax/sn1));    CE=zeros(I_evalmax,2); % ������
       
% F_weight        DE-stepsize F_weight ex [0, 2]
    F_weight = 0.50; 
% F_CR            crossover probabililty constant ex [0, 1]
    F_CR = 0.75; % main configuration

% I_strategy     1 --> DE/rand/1:
%                      the classical version of DE.
%                2 --> DE/local-to-best/1:
%                      a version which has been used by quite a number
%                      of scientists. Attempts a balance between robustness
%                      and fast convergence.
%                3 --> DE/best/1 with jitter:
%                      taylored for small population sizes and fast convergence.
%                      Dimensionality should not be too high.
%                4 --> DE/rand/1 with per-vector-dither:
%                      Classical DE with dither to become even more robust.
%                5 --> DE/rand/1 with per-generation-dither:
%                      Classical DE with dither to become even more robust.
%                      Choosing F_weight = 0.3 is a good start here.
%                6 --> DE/rand/1 either-or-algorithm:
%                      Alternates between differential mutation and three-point-
%                      recombination.           

		I_strategy = 2;

% I_refresh     intermediate output will be produced after "I_refresh"
%               iterations. No intermediate output will be produced
%               if I_refresh is < 1
        I_refresh = 1; 

% I_plotting    Will use plotting if set to 1. Will skip plotting otherwise.
        I_plotting = 0;

%-----Problem dependent constant values for plotting----------------

if (I_plotting == 1)
  FVc_xx = [-2:0.125:2]';
  FVc_yy = [-1:0.125:3]';
  [FVr_x,FM_y]=meshgrid(FVc_xx',FVc_yy') ;
  FM_meshd = 100.*(FM_y-FVr_x.*FVr_x).^2 + (1-FVr_x).^2; 

  S_struct.FVc_xx    = FVc_xx;
  S_struct.FVc_yy    = FVc_yy;
  S_struct.FM_meshd  = FM_meshd; 
end

S_struct.I_NP         = I_NP;
S_struct.F_weight     = F_weight;
S_struct.F_CR         = F_CR;
S_struct.I_D          = I_D;
S_struct.FVr_minbound = FVr_minbound;
S_struct.FVr_maxbound = FVr_maxbound;
S_struct.eta          = eta;
S_struct.I_bnd_constr = I_bnd_constr;
S_struct.I_itermax    = I_itermax;
S_struct.I_evalmax    = I_evalmax;
S_struct.sn1          = sn1;
S_struct.gfs          = gfs;
S_struct.CE           = CE;
S_struct.F_VTR        = F_VTR;
S_struct.I_strategy   = I_strategy;
S_struct.I_refresh    = I_refresh;
S_struct.I_plotting   = I_plotting;

%********************************************************************
% Start of optimization
%********************************************************************

p=gcp('nocreate');
if isempty(p)
    parpool(5);%open
% else
%     delete(gcp('nocreate'));%close
end

runs = 30;
time_begin = tic;

parfor r=1:runs
% for r=1:runs

    r

    [FVr_x,S_y,I_nf,gfs] = MADE(fname,S_struct);    % MADE

    gsamp1(r,:)=gfs;
    num_eval(r)=I_nf; % for counting the number of real-evaluations when terminated by I_itermax
    run_LS(r)=Count_LS;
%     population_diversity(r,:)=pd; % for population diversity visualization when terminated ny I_itermax
end


best_samp=min(gsamp1(:,end));
worst_samp=max(gsamp1(:,end));
samp_mean=mean(gsamp1(:,end));
samp_median=median(gsamp1(:,end));
std_samp=std(gsamp1(:,end));
out1=[best_samp,worst_samp,samp_median,samp_mean,std_samp];
gsamp1_ave=mean(gsamp1,1); 
gsamp1_log=log(gsamp1_ave);
for j=1:I_evalmax
    if mod(j,sn1)==0
        j1=j/sn1; gener_samp1(j1)=j;
    end
end

figure(1);
plot(gener_samp1,gsamp1_log,'.-k','Markersize',16)
% plot(gener_samp1,gsamp1_ave,'.-k','Markersize',16)
legend('MADE'); 
% xlim([100,I_evalmax]);
xlabel('Function Evaluation Calls');
ylabel('Mean Fitness Value (Natural Log)');
set(gca,'FontSize',20);

time_cost=toc(time_begin);
