function [FrontSet, FrontRank, IndiFront] = FastNonDominatedSort(popsize,objectives,fitness)
% fitness=[S_gpval',-MSE']; [FrontSet FrontRank IndiFront] = FastNonDominatedSort(I_HS,2,fitness);
    SetDominate = cell(popsize,1); % ֧�伯
    NDominated = zeros(popsize,1); % ֧����
    FrontRank = 1;
    FrontSet = cell(popsize,1);
    IndiFront = zeros(popsize,1);
    for i=1:popsize
        SetDominate{i} = [];
        NDominated(i,1) = 0;
        for j=1:popsize
            if i~=j
                dominate = 1; %show whether the current individual dominates others
                dominated = 1; %show whether the current individual is dominated by others;
                for o=1:objectives
                    if fitness(i,o) > fitness(j,o) % ����һ��Ŀ������������˵��i��֧��j
                        dominate = 0;
                        break;
                    end
                end
                if dominate == 0
                    for o=1:objectives
                        if fitness(i,o) < fitness(j,o) 
                            dominated = 0;
                            break;
                        end
                    end
                end
                if dominate == 1
                    SetDominate{i} = union(SetDominate{i},j);
                else
                    if dominated == 1
                        NDominated(i,1) = NDominated(i,1) + 1;
                    end
                end
            end
        end
        if NDominated(i,1) == 0
            FrontSet{FrontRank} = union(FrontSet{FrontRank},i); %The first pareto front
            IndiFront(i) = FrontRank; % ����������ָ��
        end
    end
    front = FrontRank; %current front to deal
    CurrentFront = FrontSet{FrontRank}; %Assign the individuals in the current pareto front to CurrentFront
    while size(CurrentFront,1) ~= 0
        TempSet = []; % a temporary set to save the next pareto front
        for fs = 1: size(CurrentFront',1)            
            DominateIndi = SetDominate{CurrentFront(1,fs)}; % for each individual in the current pareto front, find the individuals it dominates, and assign to DominateIndi
            for k=1:size(DominateIndi',1)
                NDominated(DominateIndi(1,k),1) = NDominated(DominateIndi(1,k),1) - 1;
                if NDominated(DominateIndi(1,k),1) == 0
                    front = FrontRank + 1;
                    TempSet = union(TempSet, DominateIndi(1,k));
                    IndiFront(DominateIndi(1,k)) = front;
                end
            end
        end
        if FrontRank ~= front
            FrontRank = front;
            FrontSet{FrontRank} = TempSet;
            CurrentFront = FrontSet{FrontRank};
        else
            CurrentFront = [];
        end
    end

        
end