%========================================================================
%******************* GP-NSGAII-RBF.MOSO (-MADE-)*************************
%========================================================================

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function:         [FVr_bestmem,S_bestval,I_nfeval] = deopt(fname,S_struct)
%                    
% Author:           Rainer Storn, Ken Price, Arnold Neumaier, Jim Van Zandt
% Description:      Minimization of a user-supplied function with respect to x(1:I_D),
%                   using the differential evolution (DE) algorithm.
%                   DE works best if [FVr_minbound,FVr_maxbound] covers the region where the
%                   global minimum is expected. DE is also somewhat sensitive to
%                   the choice of the stepsize F_weight. A good initial guess is to
%                   choose F_weight from interval [0.5, 1], e.g. 0.8. F_CR, the crossover
%                   probability constant from interval [0, 1] helps to maintain
%                   the diversity of the population but should be close to 1 for most. 
%                   practical cases. Only separable problems do better with CR close to 0.
%                   If the parameters are correlated, high values of F_CR work better.
%                   The reverse is true for no correlation.
%
%                   The number of population members I_NP is also not very critical. A
%                   good initial guess is 10*I_D. Depending on the difficulty of the
%                   problem I_NP can be lower than 10*I_D or must be higher than 10*I_D
%                   to achieve convergence.
%
%                   deopt is a vectorized variant of DE which, however, has a
%                   property which differs from the original version of DE:
%                   The random selection of vectors is performed by shuffling the
%                   population array. Hence a certain vector can't be chosen twice
%                   in the same term of the perturbation expression.
%                   Due to the vectorized expressions deopt executes fairly fast
%                   in MATLAB's interpreter environment.
%
% Parameters:       fname        (I)    String naming a function f(x,y) to minimize.
%                   S_struct     (I)    Problem data vector (must remain fixed during the
%                                       minimization). For details see Rundeopt.m.
%                   ---------members of S_struct----------------------------------------------------
%                   F_VTR        (I)    "Value To Reach". deopt will stop its minimization
%                                       if either the maximum number of iterations "I_itermax"
%                                       is reached or the best parameter vector "FVr_bestmem" 
%                                       has found a value f(FVr_bestmem,y) <= F_VTR.
%                   FVr_minbound (I)    Vector of lower bounds FVr_minbound(1) ... FVr_minbound(I_D)
%                                       of initial population.
%                                       *** note: these are not bound constraints!! ***
%                   FVr_maxbound (I)    Vector of upper bounds FVr_maxbound(1) ... FVr_maxbound(I_D)
%                                       of initial population.
%                   I_D          (I)    Number of parameters of the objective function. 
%                   I_NP         (I)    Number of population members.
%                   I_itermax    (I)    Maximum number of iterations (generations).
%                   F_weight     (I)    DE-stepsize F_weight from interval [0, 2].
%                   F_CR         (I)    Crossover probability constant from interval [0, 1].
%                   I_strategy   (I)    1 --> DE/rand/1             
%                                       2 --> DE/local-to-best/1             
%                                       3 --> DE/best/1 with jitter  
%                                       4 --> DE/rand/1 with per-vector-dither           
%                                       5 --> DE/rand/1 with per-generation-dither
%                                       6 --> DE/rand/1 either-or-algorithm
%                   I_refresh     (I)   Intermediate output will be produced after "I_refresh"
%                                       iterations. No intermediate output will be produced
%                                       if I_refresh is < 1.
%                                       
% Return value:     FVr_bestmem      (O)    Best parameter vector.
%                   S_bestval.I_nc   (O)    Number of constraints
%                   S_bestval.FVr_ca (O)    Constraint values. 0 means the constraints
%                                           are met. Values > 0 measure the distance
%                                           to a particular constraint.
%                   S_bestval.I_no   (O)    Number of objectives.
%                   S_bestval.FVr_oa (O)    Objective function values.
%                   I_nfeval         (O)    Number of function evaluations.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [FVr_bestmem,S_bestval,I_nfeval,gfs] = MADE(fname,S_struct)
%-----This is just for notational convenience and to keep the code uncluttered.--------
I_NP         = S_struct.I_NP; % ��Ⱥ��ģ
F_weight     = S_struct.F_weight; % ��������
F_CR         = S_struct.F_CR; % ������
I_D          = S_struct.I_D; % ά��
FVr_minbound = S_struct.FVr_minbound; % �½�
FVr_maxbound = S_struct.FVr_maxbound; % �Ͻ�
I_bnd_constr = S_struct.I_bnd_constr;
I_itermax    = S_struct.I_itermax; % ����������
I_evalmax    = S_struct.I_evalmax; % ������۴���
sn1          = S_struct.sn1;
gfs          = S_struct.gfs;
CE           = S_struct.CE ;
F_VTR        = S_struct.F_VTR; % Ŀ��Ԥ������ֵ
I_strategy   = S_struct.I_strategy; % �������
I_refresh    = S_struct.I_refresh; % �����ʾ
I_plotting   = S_struct.I_plotting; % ��ͼ����

%-----Check input variables---------------------------------------------
if (I_NP < 5)
   I_NP=5;
   fprintf(1,' I_NP increased to minimal value 5\n');
end
if ((F_CR < 0) || (F_CR > 1))
   F_CR=0.5;
   fprintf(1,'F_CR should be from interval [0,1]; set to default value 0.5\n');
end
if (I_itermax <= 0)
   I_itermax = 200;
   fprintf(1,'I_itermax should be > 0; set to default value 200\n');
end
I_refresh = floor(I_refresh);

%-----Initialize population and some arrays-------------------------------
FM_pop = zeros(I_NP,I_D); %initialize FM_pop to gain speed

%----FM_pop is a matrix of size I_NP x (I_D+1). It will be initialized------
%----with random values between the min and max values of the-------------
%----parameters-----------------------------------------------------------
if I_D < 100
    I_alpha = I_NP;  % ��ʼ���ݿ������� for 30d & 50d
else
%     disp('you are working at 100-D problems!')
    I_alpha = 250; % for 100d : ��ά����£�GP ����ʧЧ�������������ڹ�ֵ��ģ�;��ȣ�
end

% FM_pop = repmat(FVr_minbound,I_alpha,1) + lhsdesign(I_alpha,I_D).*(repmat(FVr_maxbound,I_alpha,1) - repmat(FVr_minbound,I_alpha,1));
FM_pop = repmat(FVr_minbound,I_alpha,1) + SLHDstandard(I_D,I_alpha).*(repmat(FVr_maxbound,I_alpha,1) - repmat(FVr_minbound,I_alpha,1));

FM_popold     = zeros(size(FM_pop));  % toggle population
FVr_bestmem   = zeros(1,I_D);         % best population member ever
FVr_bestmemit = zeros(1,I_D);         % best population member in iteration
I_nfeval      = 0;                    % number of function evaluations
S_val=zeros(1,I_alpha);
%------Evaluate the best member after initialization----------------------
I_best_index   = 1;                   % start with first population member
S_val(1)       = feval(fname,FM_pop(I_best_index,:));
S_bestval = S_val(1);                 % best objective function value so far
I_nfeval  = I_nfeval + 1;
if I_nfeval <= I_evalmax 
    CE(I_nfeval,:)=[I_nfeval,S_val(1)];
    if mod (I_nfeval,sn1)==0
        cs1=I_nfeval/sn1; gfs(1,cs1)=min(CE(1:I_nfeval,2));
    end
end
for k=2:I_alpha                          
    S_val(k)  = feval(fname,FM_pop(k,:));
    I_nfeval = I_nfeval + 1;
    if I_nfeval <= I_evalmax 
        CE(I_nfeval,:)=[I_nfeval,S_val(k)];
        if mod (I_nfeval,sn1)==0
            cs1=I_nfeval/sn1; gfs(1,cs1)=min(CE(1:I_nfeval,2));
        end
    end
    if S_val(k) < S_bestval
        I_best_index   = k;              % save its location
        S_bestval      = S_val(k);
    end
end

FVr_bestmemit = FM_pop(I_best_index,:); % best member of current iteration
S_bestvalit   = S_bestval;              % best value of current iteration

FVr_bestmem = FVr_bestmemit;            % best member ever
hx=FM_pop; hf=S_val;                    % ��ʼ����ʷ���ݿ�

[~,idx]=sort(hf); idx=idx(1:I_NP); FM_pop=hx(idx,:);% ��ʼ����Ⱥ


%------DE-Minimization---------------------------------------------
%------FM_popold is the population which has to compete. It is--------
%------static through one iteration. FM_pop is the newly--------------
%------emerging population.----------------------------------------
FM_pm1   = zeros(I_NP,I_D);   % initialize population matrix 1
FM_pm2   = zeros(I_NP,I_D);   % initialize population matrix 2
FM_pm3   = zeros(I_NP,I_D);   % initialize population matrix 3
FM_pm4   = zeros(I_NP,I_D);   % initialize population matrix 4
FM_pm5   = zeros(I_NP,I_D);   % initialize population matrix 5
FM_bm    = zeros(I_NP,I_D);   % initialize FVr_bestmember  matrix
FM_ui    = zeros(I_NP,I_D);   % intermediate population of perturbed vectors
FM_mui   = zeros(I_NP,I_D);   % mask for intermediate population
FM_mpo   = zeros(I_NP,I_D);   % mask for old population
FVr_rot  = (0:1:I_NP-1);         % rotating index array (size I_NP)
FVr_rotd = (0:1:I_D-1);          % rotating index array (size I_D)
FVr_rt   = zeros(I_NP);                % another rotating index array
FVr_rtd  = zeros(I_D);                 % rotating index array for exponential crossover
FVr_a1   = zeros(I_NP);                % index array
FVr_a2   = zeros(I_NP);                % index array
FVr_a3   = zeros(I_NP);                % index array
FVr_a4   = zeros(I_NP);                % index array
FVr_a5   = zeros(I_NP);                % index array
FVr_ind  = zeros(4);

FM_meanv = ones(I_NP,I_D);

I_iter = 1;

% main loop
while ((I_nfeval < I_evalmax) && (S_bestval > F_VTR))     
    
    FM_popold = FM_pop;                  % save the old population
    S_struct.FM_pop = FM_pop;
    S_struct.FVr_bestmem = FVr_bestmem;
    FVr_ind = randperm(4);               % index pointer array
    
    FVr_a1  = randperm(I_NP);                   % shuffle locations of vectors
    FVr_rt  = rem(FVr_rot+FVr_ind(1),I_NP);     % rotate indices by ind(1) positions: ������
    FVr_a2  = FVr_a1(FVr_rt+1);                 % rotate vector locations
    FVr_rt  = rem(FVr_rot+FVr_ind(2),I_NP);
    FVr_a3  = FVr_a2(FVr_rt+1);                
    FVr_rt  = rem(FVr_rot+FVr_ind(3),I_NP);
    FVr_a4  = FVr_a3(FVr_rt+1);               
    FVr_rt  = rem(FVr_rot+FVr_ind(4),I_NP);    
    FVr_a5  = FVr_a4(FVr_rt+1);     
    
    FM_pm1 = FM_popold(FVr_a1,:);             % shuffled population 1
    FM_pm2 = FM_popold(FVr_a2,:);             % shuffled population 2
    FM_pm3 = FM_popold(FVr_a3,:);             % shuffled population 3
    FM_pm4 = FM_popold(FVr_a4,:);             % shuffled population 4
    FM_pm5 = FM_popold(FVr_a5,:);             % shuffled population 5
    
    for k=1:I_NP                              % population filled with the best member
        FM_bm(k,:) = FVr_bestmemit;               % of the last iteration
    end
%     FM_bm=repmat(FVr_bestmemit,I_NP,1);
    
    FM_mui = rand(I_NP,I_D) < F_CR;  % all random numbers < F_CR are 1, 0 otherwise
    FM_mpo = FM_mui < 0.5;    % inverse mask to FM_mui
    if (I_strategy == 1)                             % DE/rand/1
        FM_ui = FM_pm3 + F_weight*(FM_pm1 - FM_pm2);   % differential variation
        FM_ui = FM_popold.*FM_mpo + FM_ui.*FM_mui;     % crossover
        FM_origin = FM_pm3;
    elseif (I_strategy == 2)                         % DE/local-to-best/1
        FM_ui = FM_popold + F_weight*(FM_bm-FM_popold) + F_weight*(FM_pm1 - FM_pm2);
        FM_ui = FM_popold.*FM_mpo + FM_ui.*FM_mui;
        FM_origin = FM_popold;
    elseif (I_strategy == 3)                         % DE/best/1 with jitter
        FM_ui = FM_bm + (FM_pm1 - FM_pm2).*((1-0.9999)*rand(I_NP,I_D)+F_weight);
        FM_ui = FM_popold.*FM_mpo + FM_ui.*FM_mui;
        FM_origin = FM_bm;
    elseif (I_strategy == 4)                         % DE/rand/1 with per-vector-dither
        f1 = ((1-F_weight)*rand(I_NP,1)+F_weight);
    for k=1:I_D
        FM_pm5(:,k)=f1;
    end
        FM_ui = FM_pm3 + (FM_pm1 - FM_pm2).*FM_pm5;    % differential variation
        FM_origin = FM_pm3;
        FM_ui = FM_popold.*FM_mpo + FM_ui.*FM_mui;     % crossover
    elseif (I_strategy == 5)                          % DE/rand/1 with per-vector-dither
        f1 = ((1-F_weight)*rand+F_weight);
        FM_ui = FM_pm3 + (FM_pm1 - FM_pm2)*f1;         % differential variation
        FM_origin = FM_pm3;
        FM_ui = FM_popold.*FM_mpo + FM_ui.*FM_mui;     % crossover
    else                                               % either-or-algorithm
        if (rand < 0.5)                                % Pmu = 0.5
            FM_ui = FM_pm3 + F_weight*(FM_pm1 - FM_pm2);% differential variation
        else                                           % use F-K-Rule: K = 0.5(F+1)
            FM_ui = FM_pm3 + 0.5*(F_weight+1.0)*(FM_pm1 + FM_pm2 - 2*FM_pm3);
        end
        FM_origin = FM_pm3;
        FM_ui = FM_popold.*FM_mpo + FM_ui.*FM_mui;     % crossover     
    end    
    %-----Select which vectors are allowed to enter the new population------------
    
    %=====Only use this if boundary constraints are needed==================
    for k=1:I_NP      
        if (I_bnd_constr == 1)
            for j=1:I_D                %----boundary constraints via bounce back-------
                if (FM_ui(k,j) > FVr_maxbound(j))
                    FM_ui(k,j) = FVr_maxbound(j) + rand*(FM_origin(k,j) - FVr_maxbound(j));
                end
                if (FM_ui(k,j) < FVr_minbound(j))
                    FM_ui(k,j) = FVr_minbound(j) + rand*(FM_origin(k,j) - FVr_minbound(j));
                end   
            end
        end     
    end  
    %=====End boundary constraints==========================================  
 
    FM_candi=[FM_popold;FM_ui];% �������Ӵ��Ĳ��� merged with parent pop
    
    %Global model: by diverse samples convering the search space
    %--- Training samples. surround the candidate swarm------------ T1
    phdis = real(sqrt(FM_candi.^2*ones(size(hx'))+ones(size(FM_candi))*(hx').^2-2*FM_candi*(hx'))); 
    NS = 2*(I_D+1); % ÿ�����幱�׵Ľ���������,��Ϊ���оֲ���������Ҫ��֤ģ�ͶԺ�ѡ����Ĺ�ֵ����
    
    [~,sidx] = sort(phdis,2);            % ÿ�ж���������   
    nidx = sidx;
    nidx(:,NS+1:end) = [];               % ÿ����Ⱥ����Ľ�������ָ�꼯
    nid = unique(nidx); 
    ptx = hx(nid,:); ptf = hf(nid);      % ��Χ��Ⱥ���ڽ����� 
    hxtmp=ptx;   hftmp=ptf;    
    [~,idx]=min(hftmp);
    ptx=hxtmp(idx,:);   ptf=hftmp(idx);
    
    hxtmp(idx,:)=[];    hftmp(idx)=[];
    for i=1:NS-1
        [idx,Dis]=knnsearch(ptx,hxtmp);
        [~,id]=max(Dis);
        ptx=[ptx;hxtmp(id,:)];
        ptf=[ptf,hftmp(id)];
        
        hxtmp(id,:)=[];    hftmp(id)=[];
    end
    
    ptx;    ptf;      

    % ooDACE toolbox
    gprmd1=oodacefit(ptx,ptf');
    GP=@(x) gprmd1.predict(x);%coarse model     
    [S_gpval,MSE]=GP(FM_candi); 
    S_gpval=S_gpval'; MSE=MSE';                              % GP����ģ�͹�ֵ
    
    obj1=S_gpval;
    obj2 = -MSE;

    %% ===============Nondominated ranking======================    
    [pareto_pos,pareto_index,num_front]=NSGAIIRank(FM_candi,obj1,obj2);      
    
    %% ============= Screen next population ================    
    num_pos=zeros(1,num_front);
    num=0;  FM_pop=[];  id_gpval=[];
    for i=1:num_front
        num_pos(i)=size(pareto_pos{i},1);% number of sample points in i_th Pareto front
        num=num+num_pos(i);
        if num <= I_NP
            FM_pop=[FM_pop;pareto_pos{i}];
            
            id_gpval=[id_gpval,pareto_index{i}(:,:)];
        else
            if i==1                
                % base on fitness estimator
                FM_poptmp=pareto_pos{i};% extract the samples in ith pareto front
                [~,idx]=sort(S_gpval(pareto_index{i}));% second ranking: according to estimated fitness values
                idx=idx(1:I_NP);
                FM_pop=[FM_pop;FM_poptmp(idx,:)];
                
                id_gpval_tmp=pareto_index{i};
                id_gpval=[id_gpval,id_gpval_tmp(idx)];
            else       
                % base on fitness estimator
                FM_poptmp=pareto_pos{i};% extract the samples in ith pareto front
                [~,idx]=sort(S_gpval(pareto_index{i}));% ranking based on GP fitness values
                m0=size(FM_pop,1);
                idx=idx(1:I_NP-m0);
                FM_pop=[FM_pop;FM_poptmp(idx,:)];
                
                id_gpval_tmp=pareto_index{i};
                id_gpval=[id_gpval,id_gpval_tmp(idx)];
            end  
            break;
        end
    end       
%------------- Exact evaluation part ---------------
    [~,id,~]=intersect(FM_candi,FM_pop,'rows');%FM_popʵ��������ܴ�����ͬ�ĸ���
    S_gpval=S_gpval(id);
    MSE=MSE(id);    

    FM_candi=FM_candi(id,:);        
    % find the individuals with exact values
    [~,~,ip]=intersect(hx,FM_candi,'rows');
    if ~isempty(ip)==1
        if length(ip)==size(FM_candi,1)% Amend in 2018.1.7 ----> 'I_NP' to 'size(FM_candi,1)'
%             disp('Offspring population repeats with the parental population!');% Adjustment: relate to diemnsionality and swarm size!!!
%             [~,idx]=sort(hf);   idx=idx(1:I_NP);% selecte the best I_NP sample to be the parental population
%             FM_pop=hx(idx,:);
            continue;
        else
            FM_candi_tmp=FM_candi;
            FM_candi_tmp(ip,:)=[];
            FM_candi=FM_candi_tmp;
            S_gpval(ip)=[];
            MSE(ip)=[];                
        end
    end         

%     %Local model: by neighborhood samples surround the candidate individuals
    phdis = real(sqrt(FM_candi.^2*ones(size(hx'))+ones(size(FM_candi))*(hx').^2-2*FM_candi*(hx'))); 
    [~,sidx] = sort(phdis,2);            % ÿ�ж���������   
    nidx = sidx;
    nidx(:,NS+1:end) = [];               % ÿ����Ⱥ����Ľ�������ָ�꼯
    nid = unique(nidx); 
    trainx = hx(nid,:); trainf = hf(nid);      % ��Χ��Ⱥ���ڽ����� 
    % -----------RBF-interpolation-min f_RBF------------
    flag='cubic';
    [lambda, gamma]=RBF(trainx,trainf',flag);
    FUN=@(x) RBF_eval(x,trainx,lambda,gamma,flag);%fine model
    S_rbfval=FUN(FM_candi); S_rbfval=S_rbfval';
    [~,k]=min(S_rbfval);% select argmin_f_RBF    

    [~,ih,~]=intersect(hx,FM_candi(k,:),'rows');
    if ~isempty(ih)==1
        S_candi=hf(ih);
    else
        S_candi=feval(fname,FM_candi(k,:));
%         S_trmem(k)=feval(fname,FM_trmem(k,:)');% for cec2014exp.benchmark
        I_nfeval = I_nfeval + 1;
        if I_nfeval <= I_evalmax 
            CE(I_nfeval,:)=[I_nfeval,S_candi];
            if mod (I_nfeval,sn1)==0
                cs1=I_nfeval/sn1; gfs(1,cs1)=min(CE(1:I_nfeval,2));
            end
        end
        hx=[hx;FM_candi(k,:)];  hf=[hf,S_candi];     % update history database
        if S_candi < S_bestval
            S_bestval = S_candi;                          % new best value
            FVr_bestmem = FM_candi(k,:);                  % new best parameter vector ever
        end    
    end

    FVr_bestmemit = FVr_bestmem;         % freeze the best member of this iteration for the coming 
                                             % iteration. This is needed for some of the strategies.      
%     end % End 'if mod ...'
    
%----Output section----------------------------------------------------------
    if (I_refresh > 0)
        if ((rem(I_iter,I_refresh) == 0) || I_iter == 1)
            fprintf(1,'Iteration: %d,  No.evaluation: %d,  Best fitness: %e\n',I_iter,I_nfeval,S_bestval);
%             fprintf(1,'Iteration: %d, No.evaluation: %d, minf index: %d, maxMSE index: %d, EI index: %d, PoI index: %d, LCB index: %d, Best fitness: %e\n',I_iter,I_nfeval,k_criteria(I_iter,:),S_bestval);
        end
    end     
    I_iter = I_iter + 1;
end %---end while ((I_iter < I_itermax) ...
