The ooDACE Toolbox - README
------------------------------

Please see the getting started in the doc directory:
        doc/gettingstarted.pdf (pdf version)
        
For more information about the code structure there is doxygen documentation:
        doc/html/index.hml (open in a web browser)
        doc/refman.pdf

In addition, there is online documentation at:
        http://sumowiki.intec.ugent.be/index.php/ooDACE:ooDACE_toolbox
