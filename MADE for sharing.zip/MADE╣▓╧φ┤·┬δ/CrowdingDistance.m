%% ===============Crowding distance=========================
function [CrowdDis, pop_sel] = CrowdingDistance(pareto_pos,pareto_index,obj1,obj2,NP)
    % obj1=S_gpval; obj2=MSE;
    % pareto_pos=pareto_pos{i};
    % pareto_index=pareto_index{i};
    % frontno: current pareto front;
    % NP: NP <= I_NP.
    
    pop_index = pareto_index;
    pop_pos   = pareto_pos;
    
    num_pop=size(pareto_pos,1);
    
    obj1_value = obj1(pareto_index);% pareto���ϵ�������GPֵ
    max_obj1 = max(obj1_value);       
    min_obj1 = min(obj1_value);
    
    obj2_value = obj2(pareto_index);% pareto���ϵ�������MSEֵ
    max_obj2 = max(obj2_value);       
    min_obj2 = min(obj2_value);

    obj_value = [obj1_value;  obj2_value];
    m_obj   = [max_obj1,	min_obj1;...
               max_obj2,    min_obj2];
    m_obj_ero=m_obj(:,1)-m_obj(:,2);
    
    [~,id1] = sort(obj1_value); 
    [~,id2] = sort(obj2_value);               
    id = [id1;id2];% ������ָ�꼯  
    
    obj1_value_afterrank = obj_value(1,id1);% gpval values after ranking
    obj2_value_afterrank = obj_value(2,id2);% MSE values after ranking
    obj_value_afterrank  = [obj1_value_afterrank;obj2_value_afterrank];        
    
    I_dis=zeros(2,num_pop);
    for k=1:2% ����ÿһ��Ŀ��
        I_dis(k,[1,end])=[inf,inf];   
        for jj=2:num_pop-1
            I_dis(k,jj)=(obj_value_afterrank(k,jj+1)-obj_value_afterrank(k,jj-1))/m_obj_ero(k);% ������ֵ
        end
        I_dis(k,:)=I_dis(k,id(k,:));% ��Ӧ original ָ�꼯
    end
    I_dis=mean(I_dis);
    
    CrowdDis = I_dis;
    [~,id_dis]=sort(CrowdDis,'descend');
    id_dis=id_dis(1:NP);
    pop_sel=pop_pos(id_dis,:);        
end

