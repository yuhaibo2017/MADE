var searchData=
[
  ['basicgaussianprocess',['BasicGaussianProcess',['../class_basic_gaussian_process.html',1,'']]],
  ['blindkriging',['BlindKriging',['../class_blind_kriging.html',1,'']]]
];
