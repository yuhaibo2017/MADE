var searchData=
[
  ['dist',['dist',['../class_basic_gaussian_process.html#a8871762dddde8a7dbde82d6603e8782c',1,'BasicGaussianProcess']]],
  ['distidxpsi',['distIdxPsi',['../class_basic_gaussian_process.html#a8fdbf26960e1ee465687cbd1a9177082',1,'BasicGaussianProcess']]]
];
